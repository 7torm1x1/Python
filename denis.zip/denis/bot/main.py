import telebot

bot = telebot.TeleBot('API:6168246563:AAGE60eBgmxVwC2owKRCIC9i3mLzA4T8MfI')
heroes=["Storm Spirit", "Tinker", "Void Spirit", "Shadow Fiend", "Outworld Destroyer", "Invoker", "Puck", "Ember Spirit", "Templar Assassin", "Arc Warden", "Queen of Pain",
"Meepo", "Zeus", "Huskar", "Sniper", "Leshrac", "Lina", "Death Prophet", "Viper", "Silencer", "Monkey King", "Razor", "Windranger", "Kunkka", "Necrophos", "Pangolier"]
heroesreturn=[]
for item in heroes:
    heroesreturn.append(item)
str=''
item=''

@bot.message_handler(commands=["start"])
def start(m, res=False):
    bot.send_message(m.chat.id, 'Нажмите 1 чтобы зарандомить:\nНажмите 2 чтобы добавить элемент:\nНажмите 3 '
                                'чтобы удалить элемент:')

@bot.message_handler(content_types=["text"])
def handle_text(message):
    if message.text == '1':
        bot.send_message(message.chat.id, 'Я зарандомил: ' + RandomElement())
    if message.text == '2':
        bot.send_message(message.chat.id, 'Напишите назвние персонажа ')
        bot.register_next_step_handler(message,AddElement)
    if message.text == '3':
        bot.send_message(message.chat.id, 'Напишите персонажа, которого надо удалить')
        bot.register_next_step_handler(message, RemoveElement)

def RandomElement():
    if len(heroesreturn)!=0:
        index = random.randint(0, len(heroesreturn) - 1)
        str = heroesreturn[index]
        heroesreturn.remove(heroesreturn[index])
        return str
    else:
        for item in colors:
            heroesreturn.append(item)
        index = random.randint(0, len(heroesreturn) - 1)
        str = heroesreturn[index]
        heroesreturn.remove(heroesreturn[index])
        return str
def AddElement(message):
    global item
    item=message.text
    if not heroes.__contains__(item):
        heroes.append(item)
        heroesreturn.append(item)
        bot.send_message(message.from_user.id, f'Добавил героя {message.text}');
    else:
        bot.send_message(message.chat.id, f'Герой {message.text} существует, напишите новый')
        bot.register_next_step_handler(message,AddElement)
def RemoveElement(message):
    global item
    item = message.text
    if heroes.__contains__(item):
        heroes.remove(item)
        heroesreturn.remove(item)
        bot.send_message(message.from_user.id, f'Удалил Героя {message.text}');
    else:
        bot.send_message(message.from_user.id, f'Героя не существует в списке, хотите добавлю?(Скажите да)');
        bot.register_next_step_handler(message, AddElement)
bot.polling(none_stop=True, interval=0)
