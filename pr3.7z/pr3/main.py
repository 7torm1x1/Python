# number = input('Введите число')
# even = 0
# odd = 0
# for f in number:
#     i = int(f)
#     if i % 2 == 0:
#         even += 1
#     else:
#         odd += 1
# print(f'у числа {number}: четных цифр - {even}, нечетных - {odd} ')

n = int(input('Введите число'))
s = 0
m = 1
while n>0:
    s += n%10
    m *= n%10
    n = n//10
print("Сумма:", s)
print("Произведение:", m)